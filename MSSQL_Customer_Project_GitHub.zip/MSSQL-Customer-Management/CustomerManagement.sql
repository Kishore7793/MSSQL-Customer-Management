/*
Project: Customer Management System
Database: Microsoft SQL Server
Language: T-SQL
Run in SQL Server Management Studio (SSMS).
*/

CREATE DATABASE CustomerManagementDB;
GO

USE CustomerManagementDB;
GO

CREATE TABLE dbo.Customers
(
    CustomerID  VARCHAR(26)   NOT NULL PRIMARY KEY,
    FullName    NVARCHAR(100) NOT NULL,
    Mobile      VARCHAR(30)   NULL,
    Email       NVARCHAR(254) NULL UNIQUE,
    City        NVARCHAR(100) NULL,
    CreatedDate DATETIME2(0)  NOT NULL DEFAULT SYSDATETIME()
);
GO

CREATE TABLE dbo.CustomerAudit
(
    AuditID     INT IDENTITY(1,1) PRIMARY KEY,
    CustomerID  VARCHAR(26) NOT NULL,
    ActionType  VARCHAR(10) NOT NULL,
    ChangedDate DATETIME2(0) NOT NULL DEFAULT SYSDATETIME()
);
GO

/* Stored procedure: insert a customer */
CREATE OR ALTER PROCEDURE dbo.usp_InsertCustomer
    @CustomerID VARCHAR(26),
    @FullName   NVARCHAR(100),
    @Mobile     VARCHAR(30),
    @Email      NVARCHAR(254),
    @City       NVARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO dbo.Customers
        (CustomerID, FullName, Mobile, Email, City)
    VALUES
        (@CustomerID, @FullName, @Mobile, @Email, @City);
END;
GO

/* Stored procedure: update a customer's city */
CREATE OR ALTER PROCEDURE dbo.usp_UpdateCustomer
    @CustomerID VARCHAR(26),
    @City       NVARCHAR(100)
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE dbo.Customers
    SET City = @City
    WHERE CustomerID = @CustomerID;
END;
GO

/* Function: return total customer count */
CREATE OR ALTER FUNCTION dbo.fn_GetCustomerCount()
RETURNS INT
AS
BEGIN
    DECLARE @CustomerCount INT;

    SELECT @CustomerCount = COUNT(*)
    FROM dbo.Customers;

    RETURN @CustomerCount;
END;
GO

/* Trigger: audit INSERT, UPDATE, and DELETE operations */
CREATE OR ALTER TRIGGER dbo.trg_CustomerAudit
ON dbo.Customers
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO dbo.CustomerAudit (CustomerID, ActionType)
    SELECT i.CustomerID, 'INSERT'
    FROM inserted AS i
    LEFT JOIN deleted AS d
        ON d.CustomerID = i.CustomerID
    WHERE d.CustomerID IS NULL;

    INSERT INTO dbo.CustomerAudit (CustomerID, ActionType)
    SELECT d.CustomerID, 'DELETE'
    FROM deleted AS d
    LEFT JOIN inserted AS i
        ON i.CustomerID = d.CustomerID
    WHERE i.CustomerID IS NULL;

    INSERT INTO dbo.CustomerAudit (CustomerID, ActionType)
    SELECT i.CustomerID, 'UPDATE'
    FROM inserted AS i
    INNER JOIN deleted AS d
        ON d.CustomerID = i.CustomerID;
END;
GO

/* Example execution */
EXEC dbo.usp_InsertCustomer
    @CustomerID = 'CUST1001',
    @FullName = N'Demo Customer',
    @Mobile = '9876543210',
    @Email = N'demo.customer@example.com',
    @City = N'Hyderabad';
GO

EXEC dbo.usp_UpdateCustomer
    @CustomerID = 'CUST1001',
    @City = N'Bangalore';
GO

SELECT dbo.fn_GetCustomerCount() AS TotalCustomers;
SELECT * FROM dbo.Customers;
SELECT * FROM dbo.CustomerAudit ORDER BY AuditID DESC;
GO
