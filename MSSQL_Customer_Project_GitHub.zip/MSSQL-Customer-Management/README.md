# MSSQL Customer Management Project

A beginner-friendly Microsoft SQL Server (MSSQL) project using T-SQL.

## Features
- Customer table and audit table
- Stored procedure to insert customers
- Stored procedure to update a customer's city
- Scalar function to return the customer count
- Trigger to audit INSERT, UPDATE, and DELETE operations
- Example execution and verification queries

## Requirements
- Microsoft SQL Server
- SQL Server Management Studio (SSMS)

## Run
1. Open `CustomerManagement.sql` in SSMS.
2. Execute the script using an account with permission to create databases.
3. Review the `Customers` and `CustomerAudit` tables.

## Note
The final section inserts a demo record with a sample name, phone number, and email address. Change these values before running if needed.
